

export const F1 = 'https://cdn.pixabay.com/photo/2024/07/04/20/24/data-8873303_1280.png';