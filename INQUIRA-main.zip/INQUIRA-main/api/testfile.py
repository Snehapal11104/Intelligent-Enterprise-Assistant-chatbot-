from pathlib import Path
import os



print(os.listdir())
print(os.getcwd())
print(Path("../public").exists())
